package com.demo.SpringMVCBoot.controller;

import org.springframework.web.servlet.ModelAndView;

public interface IPOPlannedController {

	public ModelAndView getIPOList() throws Exception;

}
